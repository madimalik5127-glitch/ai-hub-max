# Privacy Policy – AI Hub Max

Last updated: October 2026

AI Hub Max is a browser-style app with shortcuts to public AI websites.

- **We collect no personal data.** The app has no accounts, analytics, ads or trackers.
- **Favorites and links you add** are saved only on your device and never sent to us. A backup code is created only when you tap Export, and you decide where to keep it.
- **Third-party websites** you open inside the app have their own privacy policies. We don't control what they collect.
- **Permissions:** the app only needs internet access.
- **Children:** the app is not directed at children under 13.

Contact: YOUR_EMAIL_HERE
